#include <stdio.h>
#include <math.h>
#include "pico/stdlib.h"
#include "hardware/adc.h"
#include "hardware/dma.h"
#include "neopixel.c"

// Pino e canal do microfone no ADC.
#define MIC_CHANNEL 2
#define MIC_PIN 28

// Parâmetros e macros do ADC.
#define ADC_CLOCK_DIV 96.f
#define SAMPLES 200                                   // Número de amostras que serão feitas do ADC.
#define ADC_ADJUST(x) (x * 3.3f / (1 << 12u) - 1.65f) // Ajuste do valor do ADC para Volts.
#define ADC_MAX 3.3f
#define ADC_STEP (3.3f / 5.f) // Intervalos de volume do microfone.

// Pino e número de LEDs da matriz de LEDs.
#define LED_PIN 7
#define LED_COUNT 25

#define abs(x) ((x < 0) ? (-x) : (x))

uint16_t adc_value = 0;

// Canal e configurações do DMA
uint dma_channel;
dma_channel_config dma_cfg;

// Buffer de amostras do ADC.
uint16_t adc_buffer[SAMPLES];

uint16_t mic_get();
// float mic_power();
uint8_t get_intensity(float v);

int main()
{
    stdio_init_all();

    // Delay para o usuário abrir o monitor serial...
    sleep_ms(5000);

    // Preparação da matriz de LEDs.
    printf("Preparando NeoPixel...");

    npInit(LED_PIN, LED_COUNT);

    // Preparação do ADC.
    printf("Preparando ADC...\n");

    adc_gpio_init(MIC_PIN);
    adc_init();
    adc_select_input(MIC_CHANNEL);

    adc_fifo_setup(
        true,  // Habilitar FIFO
        true,  // Habilitar request de dados do DMA
        1,     // Threshold para ativar request DMA é 1 leitura do ADC
        false, // Não usar bit de erro
        false  // Não fazer downscale das amostras para 8-bits, manter 12-bits.
    );

    adc_set_clkdiv(ADC_CLOCK_DIV);
    // Começa a primeira conversão

    adc_fifo_drain(); // Limpa qualquer dado antigo
    adc_run(false);

    static repeating_timer_t time;
    // add_repeating_timer_ms(1000, &mic_get, NULL, &time);

    printf("ADC Configurado!\n\n");

    printf("Preparando DMA...");
    printf("\n----\nIniciando loop...\n----\n");

    while (true)
    {

        // Pega a potência média da amostragem do microfone.
        uint16_t adc_value = mic_get();
        printf("ADC -> %d\n", adc_value);
        // Limpa a matriz de LEDs.
        npClear();
        sleep_ms(100);

        if (adc_value > 800)
        {
            // Centro.
            npSetLED(12, 80, 0, 0);

            // Primeiro anel.
            npSetLED(7, 60, 60, 0);
            npSetLED(11, 60, 60, 0);
            npSetLED(13, 60, 60, 0);
            npSetLED(17, 60, 60, 0);

            // Segundo anel.
            npSetLED(2, 0, 0, 120);
            npSetLED(6, 0, 0, 120);
            npSetLED(8, 0, 0, 120);
            npSetLED(10, 0, 0, 120);
            npSetLED(14, 0, 0, 120);
            npSetLED(16, 0, 0, 120);
            npSetLED(18, 0, 0, 120);
            npSetLED(22, 0, 0, 120);

            // Terceiro anel.
            npSetLED(1, 0, 0, 80);
            npSetLED(3, 0, 0, 80);
            npSetLED(5, 0, 0, 80);
            npSetLED(9, 0, 0, 80);
            npSetLED(15, 0, 0, 80);
            npSetLED(19, 0, 0, 80);
            npSetLED(21, 0, 0, 80);
            npSetLED(23, 0, 0, 80);
        }
        else
        {
            npSetLED(12, 0, 0, 80); // Acende apenas o centro.
        }

        // Atualiza a matriz.
        npWrite();

        // tight_loop_contents();

        sleep_ms(500);
    }
}

uint16_t mic_get()
{

    adc_select_input(MIC_CHANNEL);
    uint32_t soma = 0;
    float media = 0.0;
    adc_fifo_drain();                     // Garante que FIFO está limpo
    adc_run(true);                        // Inicia o ADC
    adc_hw->cs |= ADC_CS_START_ONCE_BITS; // Inicia uma conversão única

    // Primeiro passo: calcular a média (offset DC)
    for (int i = 0; i < SAMPLES; i++)
    {
        printf("=+ ");
        uint16_t val = adc_read();
        printf(" 4=+ ");
        soma += val;
        sleep_us(20); // mais responsivo
    }
    media = (float)soma / SAMPLES;

    // Segundo passo: calcular a soma dos quadrados das diferenças
    float energia = 0.0;
    for (int i = 0; i < SAMPLES; i++)
    {
        uint16_t val = adc_read();
        float delta = (float)val - media;
        energia += delta * delta;
        sleep_us(20);
    }

    float rms = sqrtf(energia / SAMPLES); // valor eficaz (potência sonora)
    adc_value = rms;
    return adc_value;
}

/**
 * Calcula a intensidade do volume registrado no microfone, de 0 a 4, usando a tensão.
 */
uint8_t get_intensity(float v)
{
    uint count = 0;

    while ((v -= ADC_STEP / 10) > 0.f)
        ++count;

    return count;
}